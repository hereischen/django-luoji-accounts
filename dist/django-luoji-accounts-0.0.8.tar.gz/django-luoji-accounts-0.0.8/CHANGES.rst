Changelog
==============================

0.0.8 - Aug.07, 2015
------------------------------
- Changed AUDIO to IGET in fixtures



0.0.7 - Jul.30, 2015
------------------------------
- added fixtures package
- added migrations package

0.0.6 - Jul.30, 2015
------------------------------
- bugs fixing

0.0.5 - Jul.30, 2015
------------------------------
- added new field 'user_id' for Account and SunAccount
- changed _validate_user_id method in GeneralAccountManager
- added _validate_merchant_account_user_id in GeneralAccountManager


0.0.4 - Jul.29, 2015
------------------------------
- _validate_user_id method added in GeneralAccountManager


0.0.3 - Jul.29, 2015
------------------------------

- bug fixing

0.0.2 - Jul.29, 2015
------------------------------

- chanegd readme


0.0.1 - Jul.29, 2015
------------------------------

- Initail commit

