Changelog
==============================

0.0.4 - Jul.29, 2015
------------------------------
- _validate_user_id method added in GeneralAccountManager


0.0.3 - Jul.29, 2015
------------------------------

- bug fixing

0.0.2 - Jul.29, 2015
------------------------------

- chanegd readme


0.0.1 - Jul.29, 2015
------------------------------

- Initail commit

